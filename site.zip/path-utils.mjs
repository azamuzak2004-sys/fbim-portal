// Root-relative authored links become portable links for both file:// and HTTP.
export function staticURL(url,prefix){
 if(!url.startsWith('/')||url.startsWith('//'))return url;
 const match=url.match(/^([^?#]*)(.*)$/),path=match[1].slice(1);
 return prefix+path+(path===''||path.endsWith('/')?'index.html':'')+match[2];
}
export function staticMarkup(html,prefix){
 return html.replace(/\b(href|src|action)="(\/(?!\/)[^"]*)"/g,(_,attribute,url)=>`${attribute}="${staticURL(url,prefix)}"`);
}
