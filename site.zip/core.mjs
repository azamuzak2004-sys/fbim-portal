export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const safeURL = value => /^(https:\/\/|mailto:|tel:|\/(?!\/))/.test(value || '') ? escapeHTML(value) : '#';
export const moscowDate = (now = new Date()) => new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow'}).format(now);
export const isDate = value => typeof value==='string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value+'T12:00:00Z').toISOString().slice(0,10)===value;
export const addDays = (date, days) => {const d = new Date(date+'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+days); return d.toISOString().slice(0,10);};
export const dateLabel = (date, options = {}) => new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',...options,timeZone:'Europe/Moscow'}).format(new Date(date.length===10 ? date+'T12:00:00+03:00' : date));
export const weekdays = ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'];
export function eventStatus(event, now = new Date()) {
  const end = new Date(event.end || event.endDate+'T23:59:59.999+03:00');
  if (now.getTime() > end.getTime()) return 'archive';
  if (event.status === 'cancelled') return 'cancelled';
  if (event.status === 'postponed') return 'postponed';
  return 'upcoming';
}
export function occurrences(data, {from=moscowDate(),days=7,federation='',venue='',discipline='',age='',level=''}={}) {
 const rows=[];
 for(let i=0;i<days;i++) {
  const day=addDays(from,i), weekday=new Date(day+'T12:00:00Z').getUTCDay();
  for(const lesson of data.classes.filter(x=>x.published)) {
   if(federation && lesson.federation!==federation || venue && lesson.venue!==venue || discipline && lesson.discipline!==discipline || age && lesson.age!==age || level && lesson.level!==level) continue;
   if(day<lesson.validFrom || lesson.validUntil && day>lesson.validUntil) continue;
   const exception=(lesson.exceptions||[]).find(x=>x.date===day);
   if(!lesson.days.includes(weekday) && exception?.type!=='extra') continue;
   const place=data.venues.find(v=>v.id===(exception?.venue||lesson.venue)&&v.published);
   const instructor=data.instructors.find(t=>t.id===lesson.instructor&&t.published);
   if(!place || !instructor) continue;
   rows.push({...lesson,date:day,start:exception?.start||lesson.start,end:exception?.end||lesson.end,place,instructor,cancelled:exception?.type==='cancelled',note:exception?.note||lesson.note});
  }
 }
 return rows.sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));
}
