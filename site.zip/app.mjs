import {renderPage} from './render.mjs';
import {staticMarkup} from './path-utils.mjs';
// Bundled as a classic script: opens without fetch, modules or a server.
const siteRoot=new URL('.',document.currentScript.src).href;
const route=document.body.dataset.route||'/';
const data=window.FBIM_CONTENT;
function refresh(){
 try {
  const page=renderPage(data,route,new URLSearchParams(location.search));
  document.getElementById('app').innerHTML=staticMarkup(page.html,siteRoot);document.title=page.title;
  const meta=document.querySelector('meta[name="description"]');if(meta)meta.content=page.description;
  bind();
 }catch(error){console.error(error);/* Keep the readable, pre-rendered page if refresh fails. */}
}
function bind(){
 const menu=document.querySelector('.menu-toggle'),nav=document.querySelector('#navigation');
 menu?.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Закрыть меню':'Открыть меню');nav.classList.toggle('open',open);});
 document.querySelectorAll('[data-filter-form]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();const params=new URLSearchParams();for(const[k,v]of new FormData(form))if(v)params.set(k,v);const next=new URL(location.href);next.search=params.toString();next.hash='';location.assign(next.href);}));
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelector('.menu-toggle')?.setAttribute('aria-expanded','false');document.querySelector('#navigation')?.classList.remove('open');}});
refresh();
if(location.hash)requestAnimationFrame(()=>document.getElementById(decodeURIComponent(location.hash.slice(1)))?.scrollIntoView());
// Refresh event status when the page regains focus or crosses a time boundary.
setInterval(()=>{if(document.visibilityState==='visible'&&!document.querySelector('input:focus,select:focus,button:focus,a:focus'))refresh();},60000);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refresh();});
